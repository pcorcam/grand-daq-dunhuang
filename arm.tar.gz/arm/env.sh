export GRAND_DAQ_HOME=/home/root/grand-daq/arm
export GRAND_DAQ_CONFIG=${GRAND_DAQ_HOME}/grand-daq/cfgs
export GRAND_DAQ_CONFIG_LOG=${GRAND_DAQ_CONFIG}/logging
export LD_LIBRARY_PATH=${GRAND_DAQ_HOME}/external/lib:${GRAND_DAQ_HOME}/external/lib64:${GRAND_DAQ_HOME}/grand-daq/lib:${LD_LIBRARY_PATH}
export PATH=${GRAND_DAQ_HOME}/grand-daq/bin:${PATH}
